import irsim
import numpy as np

env = irsim.make('robot_world.yaml') # initialize the environment with the configuration file
# env = irsim.make('moving.yaml') # initialize the environment with the configuration file

    
for step in range(300):
    env.step()





    goal1 = env.robot_list[0].done()
    goal2 = env.robot_list[1].done()
    goal3 = env.robot_list[2].done() 
    # env.robot_list[2].set_state([1,1,2,0])

    # robot_state0 = env.robot_list   
    # robot_state0 = env.robot_list[0]._goal
    # robot_state1 = env.robot_list[1]._state
    # robot_state2 = env.robot_list[2]._state
    # # robot_state1 = env.get_robot_state()
    print(step)
    print(goal1)
    print(goal2)
    print(goal3)
    # print(env.robot_list[0].done())
    # print(robot_state1)
    env.render() # render the environment

    if env.done(): 
        break # check if the simulation is done
        
env.end() # close the environment